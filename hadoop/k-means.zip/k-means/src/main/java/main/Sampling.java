package main;

import java.io.IOException;
import java.util.HashSet;
import java.util.Random;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;

public class Sampling {

	public static class SamplingMapper extends Mapper<Text, Text, Text, Text> {
		private final Text reducerKey = new Text();
		private final Text reducerValue = new Text();

		public void map(Text key, Text value, Context context) throws IOException, InterruptedException {
			String record = value.toString().trim();
			if (record == null || record.length() == 0)
				return;
			String[] tokens = record.split(",");
			reducerKey.set(tokens[0]);
			reducerValue.set(record.substring(tokens[0].length() + 1));
			context.write(reducerKey, reducerValue);
		}
	}

	public static class SamplingReducer extends Reducer<Text, Text, Text, Text> {
		private HashSet<Integer> randoms = new HashSet<>();

		public void setup(Context context) throws IOException, InterruptedException {
			int k = context.getConfiguration().getInt("k-means.cluster.number", 1);
			int n = context.getConfiguration().getInt("k-means.matrix.size", 1);
			// random obj
			Random r = new Random();
			// generating random numbers
			for (int i = 0; i < k; i++) {
				int temp = r.nextInt(n);
				while (randoms.contains(temp))
					temp = r.nextInt(n);
				randoms.add(temp);
			}
		}

		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			if (randoms.contains(Integer.parseInt(key.toString()))) {
				context.write(key, values.iterator().next());
			}
		}
	}

}
